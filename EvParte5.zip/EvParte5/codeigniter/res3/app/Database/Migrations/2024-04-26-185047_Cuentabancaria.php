<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class Cuentabancaria extends Migration
{
   public function up()
    {
        $this->forge->addField([
            'id_Cuenta' => [
                'type'           => 'INT',
                'constraint'     => 5,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'tipocuenta' => [
                'type'       => 'VARCHAR',
                'constraint' => '100',
            ],
            'saldo' => [
                'type'       => 'INT',
                'constraint' => '100',
            ],
            'personaID' => [
                'type'       => 'VARCHAR',
                'constraint' => '100',
            ],
            
        ]);
        $this->forge->addKey('id_Cuenta', true);
        $this->forge->createTable('cuentabancaria');
    }

    public function down()
    {
        $this->forge->dropTable('cuentabancaria');
    }
}
