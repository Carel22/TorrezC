<?php 

    $id_Cuenta = $datos[0]['id_Cuenta'];
    $tipocuenta = $datos[0]['tipocuenta'];
    $saldo = $datos[0]['saldo'];
    $personaID = $datos[0]['personaID']; 
 ?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Actualizar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  </head>
  <body>

    <div class="container">
        <h1>ABC con Codeigniter 4</h1>
        <div class="row">
            <div class="col-sm-12">
                <form method="POST" action="<?php echo base_url().'/actualizar' ?>">
                <input type="text" id="id_Cuenta" name="id_Cuenta" hidden="" 
                    value="<?php echo $id_Cuenta ?>">

                    <label for="tipocuenta">Tipo Cuenta</label>
                    <input type="text" name="tipocuenta" id="tipocuenta" class="form-control" 
                    value="<?php echo $tipocuenta ?>">

                    <label for="saldo">Saldo</label>
                    <input type="text" name="saldo" id="saldo" class="form-control" 
                    value="<?php echo $saldo ?>">

                    <label for="personaID">Carnet de Identidad</label>
                    <input type="text" name="personaID" id="personaID" class="form-control" 
                    value="<?php echo $personaID ?>">
                    <br>
                    <button class="btn btn-warning">Guardar</button>
                </form>
            </div>
        </div>
        </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</body>
</html>