<?php namespace App\Models;
    use CodeIgniter\Model;

	class CrudModel extends Model {
		public function listarCuentas() {
			$cuentas = $this->db->query("SELECT * FROM cuentabancaria");
			return $cuentas->getResult();
		}
        public function insertar($datos) {
            //insercion con queryvilder
			$cuentas = $this->db->table('cuentabancaria');
			$cuentas->insert($datos);

			return $this->db->insertID(); 
		}
        public function obtenerCuenta($data) {
			$cuentas =  $this->db->table('cuentabancaria');
			$cuentas->where($data);
			return $cuentas->get()->getResultArray();
		}

		public function actualizar($data, $id_Cuenta) {
			$cuentas = $this->db->table('cuentabancaria');
			$cuentas->set($data);
			$cuentas->where('id_Cuenta', $id_Cuenta);
			return $cuentas->update();
		}

		public function borrar($data) {
			$cuentas = $this->db->table('cuentabancaria');
			$cuentas->where($data);
			return $cuentas->delete();
		}
		}